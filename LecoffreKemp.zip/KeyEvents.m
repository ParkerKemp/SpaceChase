(* ::Package:: *)

BeginPackage["KeyEvents`"]
<< JLink`

initJLink::usage="Initializes JLink, along with the things necessary for key event handling."

keyDown

initWindow::usage="Create the main window. Must be called after initJLink."

drawScene::usage="Draws the scene."

startGameLoop::usage="Starts the game loop."

Begin["Private`"]

keyDown[e_,char_,code_]:=Module[
{},
Global`playerLocation[[2]]-=1;
]

initJLink[]:=Module[
{},
ReinstallJava[];
LoadJavaClass["java.lang.System"];
]

initWindow[]:=Module[
{},
listenerClass=LoadJavaClass["com.wolfram.jlink.MathKeyListener"];
listener=JavaNew[listenerClass,{{"keyPressed","KeyEvents`keyDown"},{"keyReleased","KeyEvents`keyDown"},{"keyTyped","KeyEvents`keyDown"}}];

frame=JavaNew["com.wolfram.jlink.MathFrame"];
frame@setLayout[JavaNew["java.awt.BorderLayout"]];
canvas=JavaNew["com.wolfram.jlink.MathCanvas"];
frame@add["Center", canvas];
canvas@setMathCommand["drawScene2[]"];
frame@addKeyListener[listener];
frame@setSize[700,700];
frame@layout[];
JavaShow[frame];
ShowJavaConsole[];
]

drawScene[]:=Module[
{},
canvas@recompute[];
]

drawPlayer[]:=Module[
{},
System`out@println["Drawing player..."];
]

startGameLoop[]:=Module[
{},
RunScheduledTask[drawScene[], 0.05]
]

End[]

EndPackage[]
